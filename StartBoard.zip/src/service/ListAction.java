package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ctrl.FrontController;
import model.BoardDAO;
import model.BoardDTO;

public class ListAction implements Action {

	private static Logger log = LoggerFactory.getLogger(FrontController.class);

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) {
		// TODO Auto-generated method stub
		BoardDAO bdao = new BoardDAO();
//		ArrayList<BoardDTO> bList = new ArrayList<>();
//		bList = bdao.getList();

		ArrayList<BoardDTO> bList = null;
		try {
			bList = (ArrayList<BoardDTO>) bdao.getList();
			if (bList == null) {
				log.info("Getting Data List Fail From DB");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		req.setAttribute("bList", bList);

	}

}
