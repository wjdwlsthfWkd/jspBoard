package service;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ctrl.FrontController;
import model.BoardDAO;
import model.BoardDTO;

public class DeleteAction implements Action {
	private static Logger log = LoggerFactory.getLogger(FrontController.class);
	
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) {
		int bno = Integer.parseInt(req.getParameter("clno"));
		
		BoardDAO bdao = new BoardDAO();
		boolean flag;
		try {
			flag = bdao.delete(bno);
			if (flag)
				log.info(">>> Delete Data Success");
			else
				log.info(">>> Delete Data Fail");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.setAttribute("clno", bno);
	}

}
